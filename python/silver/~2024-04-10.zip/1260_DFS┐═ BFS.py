'''import sys
from collections import deque
import copy
input = sys.stdin.readline
n, m, v = map(int, input().split())
dfs_ans = []
bfs_ans = []


def update_node(dic, n, e):
    if n not in dic:
        dic[n] = [False, set([e])]
    else:
        dic[n][1].add(e)
def dfs(nodes, start):
    global dfs_ans
    dfs_ans.append(str(start))
    nodes[start][0] = True
    for next in nodes[start][1]:
        if nodes[next][0] == False:
            dfs(nodes, next)

def bfs(nodes, start):
    q = deque()
    q.append(start)
    nodes[start][0] = True

    while len(q) != 0:
        now = q.popleft()
        bfs_ans.append(str(now))
        for next in nodes[now][1]:
            if nodes[next][0] == False:
                q.append(next)
                nodes[next][0] = True



nodes = {}
nodes[v] = [False, set()]
for _ in range(m):
    a, b = map(int, input().split())
    update_node(nodes, a, b)
    update_node(nodes, b, a)
for node in nodes.values():
    node[1] = sorted(node[1])

bfs(copy.deepcopy(nodes), v)
dfs(copy.deepcopy(nodes), v)
print(" ".join(dfs_ans))
print(" ".join(bfs_ans))'''

import sys
from collections import deque
input = sys.stdin.readline

n, m, v = map(int, input().split())
edges = [[False for j in range(n+1)] for i in range(n+1)]
visited = [False for _ in range(n+1)]
for _ in range(m):
    a, b = map(int, input().split())
    edges[a][b] = True
    edges[b][a] = True
dfs_ans = []
def dfs(v, visited):
    dfs_ans.append(str(v))
    visited[v] = True
    for next in range(1, n+1):
        if  edges[v][next] and not visited[next]:
            dfs(next, visited)
dfs(v, visited)
print(" ".join(dfs_ans))


def bfs(v):
    bfs_ans = []
    visited = [False for _ in range(n+1)]
    visited[v] = True
    q = deque([v])
    while q:
        now = q.popleft()
        bfs_ans.append(str(now))
        for next in range(1, n+1):
            if edges[now][next] and not visited[next]:
                q.append(next)
                visited[next] = True
    return " ".join(bfs_ans)
print(bfs(v))

import sys
input = sys.stdin.readline
write = sys.stdout.write

pokemon = {}
number = {}
n, m = map(int, input().split())
for i in range(1, n+1):
    monster = input().rstrip()
    pokemon[i] = monster
    number[monster] = i

for i in range(m):
    question = input().rstrip()
    if question.isdigit():
        write(pokemon[int(question)] + "\n")
    else:
        write(str(number[question]) + "\n")
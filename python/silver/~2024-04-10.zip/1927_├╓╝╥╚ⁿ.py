import sys
import heapq
input = sys.stdin.readline
write = sys.stdout.write
heap = []
n = int(input())
for _ in range(n):
    x = int(input())
    if x > 0:
        heapq.heappush(heap, x)
    else:
        if heap:
            write(str(heapq.heappop(heap))+"\n")
        else:
            write("0\n")
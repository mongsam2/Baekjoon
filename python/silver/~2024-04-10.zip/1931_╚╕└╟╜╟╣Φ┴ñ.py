'''import sys
input = sys.stdin.readline

n = int(input())
times = []
count = 0
for _ in range(n):
    start, end = map(int, input().split())
    times.append((start, end))
sorted_times = sorted(times, key= lambda x:[x[1], x[0]])

next_time = 0
for start, end in sorted_times:
    if start >= next_time:
        count += 1
        next_time = end
print(count)'''

import sys
input = sys.stdin.readline

n = int(input())
schedules = []
for _ in range(n):
    schedules.append(tuple(map(int, input().split())))
schedules.sort(key=lambda x : [x[1], x[0]])

pre = 0
cnt = 0
for times in schedules:
    start, end = times
    if start >= pre:
        pre = end
        cnt += 1
print(cnt)
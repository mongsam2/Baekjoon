# ** 꼭! 다시 풀어보기! **


'''from collections import deque


n = int(input())
nums = set([n])
count = 0
while nums:
    temp = set()
    for num in nums:
        if num == 1:
            print(count)
            exit()
        if num%3 == 0:
            temp.add(num//3)
        if num%2 == 0:
            temp.add(num//2)
        temp.add(num-1)
    nums = temp
    count += 1'''
from collections import deque

n = int(input())

def bfs(start):
    q = deque([(start, 0)])
    visited = set([start])
    while q:
        now, cost = q.popleft()
        if now == 1:
            return cost
        if now%3 == 0 and (now//3 not in visited):
            q.append((now//3, cost+1))
            visited.add((now//3))
        if now%2 == 0 and (now//2 not in visited):
            q.append((now//2, cost+1))
            visited.add(now//2)
        if now-1 not in visited:
            q.append((now-1, cost+1))
            visited.add(now-1)

print(bfs(n))
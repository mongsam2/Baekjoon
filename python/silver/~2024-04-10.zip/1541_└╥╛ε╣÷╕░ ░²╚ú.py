# 10 + 20 - 30 + 40
# 1 + 2 + 3 + 4 - 5 + 6 - 7 + 8
# -> 1+2+3+4 - 11 / 1+2+3+4-5+6-7+8
# 마이너스 뒤에 있는 숫자들에서 선택의 경우의 수 존재

# -26 10
'''s = input()
#total_sum(s, 0, False)
#print(total)
total = 0
sum_list = s.split("-")
for i in range(len(sum_list)):
    add = sum(map(int, sum_list[i].split("+")))
    if i == 0:
        total += add
    else:
        total -= add
print(total)
'''
# 10-4+5+8-4-7
s = input()
split_s = s.split("-")
ans = 0
for i in range(len(split_s)):
    if i == 0:  
        ans += sum(map(int, split_s[i].split("+")))
    else:
        ans -= sum(map(int, split_s[i].split("+")))
print(ans)

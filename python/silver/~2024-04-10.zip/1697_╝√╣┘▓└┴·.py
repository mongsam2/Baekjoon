'''from collections import deque

n, k = map(int, input().split())
def bfs(n, k):
    q = deque([n])
    count = 0
    visited = {n:0}
    while q:
        next = q.popleft()
        if next == k:
            return visited[next]
        plus = next+1
        minus = next-1
        mul = next*2
        if plus not in visited and plus <= 100000:
            q.append(plus)
            visited[plus] = visited[next] + 1
        if minus not in visited and minus >= 0:
            q.append(minus)
            visited[minus] = visited[next] + 1
        if mul not in visited and mul <= 100000:
            q.append(mul)
            visited[mul] = visited[next] + 1
print(bfs(n, k))'''

from collections import deque
n, k = map(int, input().split())
nums = [False for _ in range(100001)]
def bfs(n, k):
    global nums
    if n==k:
        return 0
    q = deque([(n, 0)])
    nums[n] = True
    while q:
        now = q.popleft()
        node, count = now
        if node == k:
            return count
        for next in (node+1, node-1, node*2):
            if next <= 100000 and next >= 0 and not nums[next]:
                q.append((next, count+1))
                nums[next] = True
print(bfs(n, k))

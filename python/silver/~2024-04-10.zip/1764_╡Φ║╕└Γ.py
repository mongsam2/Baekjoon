import sys
input = sys.stdin.readline
write = sys.stdout.write

n, m = map(int, input().split())
didnt_heard = set()
didnt_seen = set()
for _ in range(n):
    didnt_heard.add(input().rstrip())
for _ in range(m):
    didnt_seen.add(input().rstrip())
ans = didnt_heard.intersection(didnt_seen)
ans = sorted(ans)
write(str(len(ans))+"\n")
for name in ans:
    write(name+"\n")
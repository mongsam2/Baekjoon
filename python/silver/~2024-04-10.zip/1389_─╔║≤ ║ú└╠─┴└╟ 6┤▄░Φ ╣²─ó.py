'''# ** 꼭! 다시 풀어보기! **

import sys
from collections import deque
input = sys.stdin.readline

n, m = map(int, input().split())

friends = [[False] * (n+1) for i in range(n+1)]
for _ in range(m):
    a, b = map(int, input().split())
    friends[a][b] = True
    friends[b][a] = True


def bfs(start, friends):
    global n
    distance = [0] * (n+1)
    visited = set()
    q = deque()
    visited.add(start)
    q.append(start)
    while len(q) != 0:
        now = q.popleft()
        for next in range(1, n+1):
            if friends[now][next] and (next not in visited):
                q.append(next)
                visited.add(next)
                distance[next] = distance[now] + 1
    return distance


total = []
for me in range(1, n+1):
    total.append(sum(bfs(me, friends)))
idx = total.index(min(total)) + 1
print(idx)
'''

import sys
from collections import deque
input = sys.stdin.readline


def update_edges(edges, a, b):
    if a not in edges:
        edges[a] = [b]
    else:
        edges[a].append(b)
    if b not in edges:
        edges[b] = [a]
    else:
        edges[b].append(a) 

def bfs(start):
    visited = [False for _ in range(n+1)]
    q = deque([(start, 0)])
    visited[start] = True
    cost = 0
    while q:
        now, distance = q.popleft()
        cost += distance
        for next in edges[now]:
            if not visited[next]:
                q.append((next, distance+1))
                visited[next] = True
    return cost



n, m = map(int, input().split())
edges = {}
for _ in range(m):
    a, b = map(int, input().split())
    update_edges(edges, a, b)
kevins = []
for i in range(1, n+1):
    kevins.append(bfs(i))

print(kevins.index(min(kevins)) + 1)



